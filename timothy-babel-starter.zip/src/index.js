import {Watcher} from "./Watcher";

Watcher.watchThis("the-target");
