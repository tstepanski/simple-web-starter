export class Printer {
    printHelloWord() {
        alert("Hello World");
    }
}
